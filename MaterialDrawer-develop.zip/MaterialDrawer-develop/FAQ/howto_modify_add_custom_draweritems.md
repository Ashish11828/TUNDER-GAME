# How do I change existing or add my own CustomDrawerItems to the MaterialDrawer?

Please head over here on how to implement a proper CustomDrawerItem:
- http://stackoverflow.com/a/32543209/325479
- http://stackoverflow.com/a/32542999/325479

Or you check out custom drawer item implementations here:
- https://github.com/mikepenz/MaterialDrawer/tree/develop/app/src/main/java/com/mikepenz/materialdrawer/app/drawerItems

You might also find some answers here:
- https://github.com/mikepenz/MaterialDrawer/issues?utf8=%E2%9C%93&q=CustomDrawerItem
